# Elite Delivery - Backend em Rust

Backend da plataforma Elite Delivery desenvolvido em **Rust com Actix-web e SQLx**.

## 📋 Pré-requisitos

- **Rust** 1.70+ (instalar em https://rustup.rs/)
- **MySQL** 8.0+ rodando localmente ou remoto
- **Cargo** (gerenciador de pacotes do Rust)

## 🚀 Configuração Rápida

### 1. Clone o Repositório

```bash
cd elite-delivery-backend
```

### 2. Configure o Banco de Dados

Crie um arquivo `.env` na raiz do projeto:

```env
DATABASE_URL=mysql://root:password@localhost:3306/bd_semnome
SERVER_HOST=127.0.0.1
SERVER_PORT=3001
JWT_SECRET=sua_chave_secreta_super_segura_aqui
CORS_ORIGIN=http://localhost:8000
```

**Substitua:**
- `root` → seu usuário MySQL
- `password` → sua senha MySQL
- `bd_semnome` → nome do seu banco de dados

### 3. Criar o Banco de Dados

Se ainda não tiver criado, execute:

```bash
mysql -u root -p
```

```sql
CREATE DATABASE bd_semnome;
USE bd_semnome;

-- Tabelas já devem estar criadas conforme seu script anterior
-- Se não estiverem, execute o script SQL que você tem
```

### 4. Instalar Dependências

```bash
cargo build
```

### 5. Executar o Servidor

```bash
cargo run
```

Você verá:
```
✅ Conectado ao banco de dados
🚀 Servidor iniciando em http://127.0.0.1:3001
```

## 📚 Endpoints da API

### Autenticação

#### Cadastro Cliente
```
POST /api/auth/cadastro-cliente
Content-Type: application/json

{
  "nome": "João Silva",
  "email": "joao@email.com",
  "telefone": "(11) 99999-0000",
  "endereco": "Rua A, 123",
  "senha": "senha123"
}
```

#### Login Cliente
```
POST /api/auth/login-cliente
Content-Type: application/json

{
  "email": "joao@email.com",
  "senha": "senha123"
}
```

#### Cadastro Empresa
```
POST /api/auth/cadastro-empresa
Content-Type: application/json

{
  "nome": "Empresa XYZ",
  "email": "empresa@email.com",
  "tipo": "PJ",
  "cnpj": "12.345.678/0001-90",
  "senha": "senha123"
}
```

#### Login Empresa
```
POST /api/auth/login-empresa
Content-Type: application/json

{
  "email": "empresa@email.com",
  "senha": "senha123"
}
```

### Lojas

#### Listar Lojas da Empresa
```
GET /api/empresas/{empresa_id}/lojas
```

#### Obter Loja Específica
```
GET /api/empresas/{empresa_id}/lojas/{loja_id}
```

#### Criar Loja
```
POST /api/empresas/{empresa_id}/lojas
Content-Type: application/json

{
  "nome": "Elite Centro",
  "descricao": "Nossa loja principal",
  "telefone": "(11) 3333-3333",
  "email": "centro@elite.com",
  "cep": "01310100",
  "logradouro": "Avenida Paulista",
  "numero": "1000",
  "bairro": "Bela Vista",
  "cidade": "São Paulo",
  "estado": "SP",
  "horario_abertura": "10:00",
  "horario_fechamento": "23:00"
}
```

#### Atualizar Loja
```
PUT /api/empresas/{empresa_id}/lojas/{loja_id}
Content-Type: application/json

{
  "nome": "Elite Centro - Atualizado",
  "horario_abertura": "09:00"
}
```

#### Deletar Loja
```
DELETE /api/empresas/{empresa_id}/lojas/{loja_id}
```

## 🔌 Integração com Frontend

### 1. Adicione o `config.js` ao seu HTML

```html
<script src="config.js"></script>
```

### 2. Use as Funções da API

```javascript
// Login
try {
  const usuario = await apiLoginCliente('email@example.com', 'senha123');
  console.log('Logado:', usuario);
} catch (error) {
  console.error('Erro:', error.message);
}

// Carregar lojas
try {
  const empresaId = localStorage.getItem('empresa_id');
  const lojas = await apiGetLojas(empresaId);
  console.log('Lojas:', lojas);
} catch (error) {
  console.error('Erro:', error.message);
}

// Criar loja
try {
  const novaLoja = await apiCreateLoja(empresaId, {
    nome: 'Elite Zona Leste',
    email: 'leste@elite.com',
    horario_abertura: '10:00',
    horario_fechamento: '23:00'
  });
  console.log('Loja criada:', novaLoja);
} catch (error) {
  console.error('Erro:', error.message);
}
```

## 🔒 Segurança

### ⚠️ Importante para Produção

1. **Senhas**: Implementar hash com bcrypt
2. **JWT**: Usar tokens JWT com expiração
3. **HTTPS**: Usar HTTPS em produção
4. **CORS**: Configurar CORS corretamente
5. **Validação**: Validar todos os inputs
6. **Rate Limiting**: Implementar rate limiting

## 📝 Estrutura do Projeto

```
elite-delivery-backend/
├── src/
│   ├── main.rs           # Servidor principal
│   ├── models.rs         # Modelos de dados
│   └── handlers/
│       ├── mod.rs        # Exportar handlers
│       ├── auth.rs       # Autenticação
│       └── lojas.rs      # CRUD de lojas
├── Cargo.toml            # Dependências
├── .env                  # Variáveis de ambiente
└── README.md             # Este arquivo
```

## 🐛 Troubleshooting

### Erro: "Erro ao conectar ao banco de dados"

```bash
# Verificar se MySQL está rodando
mysql -u root -p

# Verificar DATABASE_URL no .env
cat .env | grep DATABASE_URL
```

### Erro: "Port 3001 already in use"

```bash
# Mudar porta no .env
SERVER_PORT=3002
```

### Erro: "CORS error"

```bash
# Verificar CORS_ORIGIN no .env
# Deve corresponder à URL do seu frontend
CORS_ORIGIN=http://localhost:8000
```

## 🚀 Deploy

### Para Produção

1. Compilar release:
```bash
cargo build --release
```

2. Executar:
```bash
./target/release/elite-delivery-backend
```

3. Usar um reverse proxy (Nginx):
```nginx
server {
    listen 80;
    server_name seu-dominio.com;

    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## 📞 Suporte

Para dúvidas ou problemas, consulte:
- Documentação Actix: https://actix.rs/
- Documentação SQLx: https://github.com/launchbadge/sqlx
- Rust Book: https://doc.rust-lang.org/book/

---

**Desenvolvido com ❤️ para Elite Delivery**
